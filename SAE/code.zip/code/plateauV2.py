import random
import pygame
import sys
from dé import *
from case import Case
from bouton import Bouton
from joueur import Joueur

# Initialisation de Pygame
pygame.init()

# Définition des couleurs
BLANC = (255, 255, 255)
NOIR = (0, 0, 0)
ORANGE = (255, 165, 0)
GRIS = (200, 200, 200)

# Taille de la fenêtre et des cases
taille_case = 80
largueur = 14
hauteur = 10
largueur_fenetre = taille_case * largueur
hauteur_fenetre = taille_case * hauteur


# Création de la fenêtre
fenetre = pygame.display.set_mode((largueur_fenetre, hauteur_fenetre))
pygame.display.set_caption("Plateau de jeu")

# Initialisation de toutes les cases du plateau
case1 : Case = Case(1, 5, 8)
case2 : Case = Case(2, 4, 8)
case3 : Case = Case(3, 3, 8)
case4 : Case = Case(4, 3, 7)
case5 : Case = Case(5, 2, 7)
case6 : Case = Case(6, 1, 7)
case7 : Case = Case(7, 1, 6)
case8 : Case = Case(8, 1, 5)
case9 : Case = Case(9, 2, 5)
case10 : Case = Case(10, 2, 4)
case11 : Case = Case(11, 2, 3)
case12 : Case = Case(12, 1, 3)
case13 : Case = Case(13, 1, 2)
case14 : Case = Case(14, 1, 1)
case15 : Case = Case(15, 2, 1)
case16 : Case = Case(16, 3, 1)
case17 : Case = Case(17, 3, 2)
case18 : Case = Case(18, 4, 2)
case19 : Case = Case(19, 5, 2)
case20 : Case = Case(20, 5, 1)
case21 : Case = Case(21, 6, 1)
case22 : Case = Case(22, 7, 1)
case23 : Case = Case(23, 8, 1)
case24 : Case = Case(24, 8, 2)
case25 : Case = Case(25, 8, 3)
case26 : Case = Case(26, 8, 4)
case27 : Case = Case(27, 8, 5)
case28 : Case = Case(28, 7, 5)
case29 : Case = Case(29, 7, 6)
case30 : Case = Case(30, 7, 7)
case31 : Case = Case(31, 6, 7)
case32 : Case = Case(32, 6, 8)

# Initialisation du plateau
plateau = [[None,   None   ,   None   ,   None   ,   None   ,   None   ,   None   ,   None   ,   None   ,   None   ,   None   ,   None   ,   None   , None],
           [None,  case14  ,  case13  ,  case12  ,   None   ,  case8   ,  case7   ,  case6   ,   None   ,   None   ,    4     ,    5     ,   None   , None],
           [None,  case15  ,   None   ,  case11  ,  case10  ,  case9   ,   None   ,  case5   ,   None   ,   None   ,   None   ,   None   ,   None   , None],
           [None,  case16  ,  case17  ,   None   ,   None   ,   None   ,   None   ,  case4   ,  case3   ,   None   ,   None   ,   None   ,   None   , None],
           [None,   None   ,  case18  ,   None   ,   None   ,   None   ,   None   ,   None   ,  case2   ,   None   ,   None   ,   None   ,   None   , None],
           [None,  case20  ,  case19  ,   None   ,   None   ,   None   ,   None   ,   None   ,  case1   ,    3     ,   None   ,   None   ,   None   , None],
           [None,  case21  ,   None   ,   None   ,   None   ,   None   ,   None   ,  case31  ,  case32  ,   None   ,   None   ,   None   ,   None   , None],
           [None,  case22  ,   None   ,   None   ,   None   ,  case28  ,  case29  ,  case30  ,   None   ,   None   ,   None   ,   None   ,   None   , None],
           [None,  case23  ,  case24  ,  case25  ,  case26  ,  case27  ,   None   ,   None   ,   None   ,   None   ,   None   ,   None   ,   None   , None],
           [None,   None   ,   None   ,   None   ,   None   ,   None   ,   None   ,   None   ,   None   ,   None   ,   None   ,   None   ,   None   , None]]

# Initialisation de la liste des boutons
liste_boutons = []

j1 : Joueur = Joueur("joueur_1", case1.getX, case1.getY)
j2 : Joueur = Joueur("joueur_2", case1.getX, case1.getY)

case1.setType("Joueur")

def getCase(x,y) -> Case:
    return plateau[x][y]

def creationPlateau(plateau):
    for i in range(largueur):
        for j in range(hauteur):
            if plateau[j][i] is not None:
                if isinstance(plateau[j][i],Case):
                    case_temp = getCase(j,i)
                    if case_temp.getType() == "Joueur":
                        pygame.draw.rect(fenetre, ORANGE, (i * taille_case, j * taille_case, taille_case, taille_case))
                        fenetre.blit(pygame.image.load(j1.getImage()), (i * taille_case, j * taille_case))
                    else:
                        pygame.draw.rect(fenetre, NOIR, (i * taille_case, j * taille_case, taille_case, taille_case))
                if plateau[j][i] == 3:
                    fenetre.blit(pygame.image.load("IMG/fleche_sens.png"), (i * taille_case, j * taille_case))
                if plateau[j][i] == 4:
                    boutonDe = Bouton((i * taille_case, j * taille_case), (taille_case, taille_case), (255, 0, 0))
                    liste_boutons.append(boutonDe)
                if plateau[j][i] == 5:
                    fenetre.blit(pygame.image.load("IMG/de/de_vide.png"), (i * taille_case, j * taille_case))
                    # Pas encore opérationnel (NameError: name 'resultat_de' is not defined)
                    # if boutonDe.est_clique():
                    #     if resultat_de == 1:
                    #         fenetre.blit(pygame.image.load("IMG/de/de_1.png"), (i * taille_case, j * taille_case))
                    #     if resultat_de == 2:
                    #         fenetre.blit(pygame.image.load("IMG/de/de_2.png"), (i * taille_case, j * taille_case))
                    #     if resultat_de == 3:
                    #         fenetre.blit(pygame.image.load("IMG/de/de_3.png"), (i * taille_case, j * taille_case))                            


def deplacement(plateau,joueur: Joueur):
    if resultat_de == 1 :
        getCase(joueur.getX(), joueur.getY())
        
    if resultat_de == 2 :
        getCase(joueur.getX(), joueur.getY())
        
    if resultat_de == 3 :
        getCase(joueur.getX(), joueur.getY())
        

# Boucle pour afficher la fenêtre
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        
            
        # Initialisation du fond de la fenetre en gris clair
        fenetre.fill(GRIS)

        # Affichage du plateau
        creationPlateau(plateau)
    
    # Affichage des boutons
    for bouton in liste_boutons:
        bouton.dessiner(fenetre)
        
        if bouton.est_clique():
            print("Le bouton a ete clique")
            resultat_de = bouton.lancer_de()
            bouton.reset_clic()

        pygame.display.flip()
        
    def clicBouton(plateau):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    position_souris = pygame.mouse.get_pos()
                    for bouton in liste_boutons:
                        if bouton.est_clique(position_souris):
                            print(f"Clic gauche sur le bouton à la position {position_souris}")
    
    # Appeler la fonction pour détecter les clics des boutons
    # clicBouton(plateau)
    
    def detecter_clic_souris(plateau):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    position_souris = pygame.mouse.get_pos()
                    colonne = position_souris[0] // taille_case
                    ligne = position_souris[1] // taille_case

                    if 0 <= ligne < hauteur and 0 <= colonne < largueur:
                        print(f"Clic gauche à la position ({ligne}, {colonne})")

            pygame.display.flip()

    # Appeler la fonction pour détecter les clics de souris
    # detecter_clic_souris(plateau)