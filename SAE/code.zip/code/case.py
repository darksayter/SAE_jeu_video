from __future__ import annotations

class Case:
    
    allCases : list [Case] = []
    
    @staticmethod
    def getAllCases() ->list[Case]:
        return Case.allCases
    
    def __init__(self, id, x, y):
        self.id = id
        self.x = x
        self.y = y
        self.type = ""
        self.couleur = (0,0,0)
        Case.allCases.append(self)
        
    def __repr__(self) -> str:
        return f'Case({self.id}, {self.x}, {self.y})'
        
    def getId(self):
        return self.id
        
    def getX(self):
        return self.x
    
    def getY(self):
        return self.y
    
    def getType(self):
        return self.type
    
    def getCouleur(self):
        return self.couleur
    
    def setId(self, id):
        self.id = id
        
    def setX(self, x):
        self.x = x
        
    def setY(self, y):
        self.y = y
        
    def setType(self, type):
        self.type = type
        
    def setCouleur(self, couleur):
        self.couleur = couleur