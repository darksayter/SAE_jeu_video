import os
from pygame import *
import sys
from dé import *

# Initialisation de Pygame
pygame.init()

# Définition des couleurs
BLANC = (255, 255, 255)
NOIR = (0, 0, 0)
ORANGE = (255, 165, 0)

# Taille de la fenêtre et des cases
taille_case = 80
largueur = 14
hauteur = 10
largueur_fenetre = taille_case * largueur
hauteur_fenetre = taille_case * hauteur


# Création de la fenêtre
fenetre = pygame.display.set_mode((largueur_fenetre, hauteur_fenetre))
pygame.display.set_caption("Plateau de jeu")


# Matrice représentant le plateau de jeu (0 pour vide, 1 pour occupé, 
# 2 ligne de départ mais aussi ligne d'arrivée, 3 pour marqué le sens,
# 4 pour le bouton qui lance dé, 5 pour afficher le résultat du dé)
plateau = [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
           [0, 1, 1, 1, 0, 1, 1, 1, 0, 0, 4, 5, 0, 0],
           [0, 1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0],
           [0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0],
           [0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0],
           [0, 1, 1, 0, 0, 0, 0, 0, 2, 3, 0, 0, 0, 0],
           [0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0],
           [0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0],
           [0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0],
           [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]]

# fleche = image.load('fleche_sens.png')
# fleche = fleche.convert()

def getPositionDepart(plateau):
    depart = []
    for i in range(len(plateau)):
        for j in range(len(plateau[i])):
            if plateau[i][j] == 2:
                depart.append((i, j))
    return depart

def getPositionDeplacement(plateau):
    deplacement = []
    for i in range(len(plateau)):
        for j in range(len(plateau[i])):
            if plateau[i][j] == 1:
                deplacement.append((i, j))
    return deplacement

# Boucle pour afficher la fenêtre
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    # Affichage du plateau
    for i in range(largueur):
        for j in range(hauteur):
            if plateau[j][i] == 0: # case vide
                couleur = BLANC
            if plateau[j][i] == 1: # case de déplacement
                couleur = NOIR
            if plateau[j][i] == 2: # case départ
                couleur = ORANGE
            if plateau[j][i] == 3: # fleche sens
                pass
            if plateau[j][i] == 4: # bouton lancer dé
                pass
            if plateau[j][i] == 5: # affichage dé
                pass
            pygame.draw.rect(fenetre, couleur, (i * taille_case, j * taille_case, taille_case, taille_case))

    pygame.display.flip()
    
    def detecter_clic_souris(plateau):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    position_souris = pygame.mouse.get_pos()
                    colonne = position_souris[0] // taille_case
                    ligne = position_souris[1] // taille_case

                    if 0 <= ligne < hauteur and 0 <= colonne < largueur:
                        print(f"Clic gauche à la position ({ligne}, {colonne})")

            pygame.display.flip()

    # Appeler la fonction pour détecter les clics de souris
    detecter_clic_souris(plateau)