import pygame
import random

class Bouton:
    
    def __init__(self, position, taille, couleur):
        self.position = position
        self.taille = taille
        self.couleur = couleur
        self.clic_detecte = False

    def dessiner(self, surface):
        pygame.draw.rect(surface, self.couleur, (*self.position, *self.taille))

    def est_clique(self):
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                position_souris = pygame.mouse.get_pos()
                if (
                    self.position[0] <= position_souris[0] <= self.position[0] + self.taille[0]
                    and self.position[1] <= position_souris[1] <= self.position[1] + self.taille[1]
                    and not self.clic_detecte
                ):
                    self.clic_detecte = True
                    return True
        return False

    def reset_clic(self):
        self.clic_detecte = False

    def lancer_de(self):
        resultat_de = random.randint(1, 3)
        return resultat_de