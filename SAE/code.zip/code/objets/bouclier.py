class shield(object):
    def __init__(self, nom, armure):
        self.nom = nom
        self.armure = armure
        
    def utiliser_un_shield(self, cible):
        cible.armure += 10
        return cible.armure