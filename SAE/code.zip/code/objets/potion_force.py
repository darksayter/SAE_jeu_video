class potion_force(object):
    def __init__(self, nom, degat):
        self.nom = nom
        self.degat = degat
        
    def utiliser(self, cible):
        cible.degat += self.degat
        return cible.degat