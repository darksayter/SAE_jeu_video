class pomme(object):
    def __init__(self, nom, hp):
        self.nom = nom
        self.hp = hp
        
    def utiliser(self, cible):
        cible.hp += self.hp
        return cible.hp