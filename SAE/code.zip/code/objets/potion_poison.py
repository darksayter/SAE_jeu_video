class potion_poison(object):
    def __init__(self, nom, degat):
        self.nom = nom
        self.degat = degat
        
    def utiliser(self, cible):
        cible.hp -= self.degat
        return cible.hp