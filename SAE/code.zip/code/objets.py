class pomme(object):
    def __init__(self, nom, hp):
        self.nom = nom
        self.hp = hp
        
    def utiliser(self, cible):
        cible.hp += self.hp
        return cible.hp
    
    
class shield(object):
    def __init__(self, nom, armure):
        self.nom = nom
        self.armure = armure
        
    def utiliser_un_shield(self, cible):
        cible.armure += 10
        return cible.armure
    
    
class potion_force(object):
    def __init__(self, nom, degat):
        self.nom = nom
        self.degat = degat
        
    def utiliser(self, cible):
        cible.degat += self.degat
        return cible.degat
    
    
class potion_poison(object):
    def __init__(self, nom, degat):
        self.nom = nom
        self.degat = degat
        
    def utiliser(self, cible):
        cible.hp -= self.degat
        return cible.hp