from menu_principal import *
from menu_pers import *
from plateau import *
from joueur import *
from monstres import *
from pomme import *
from bouclier import *
from potion_force import *
from potion_poison import *

def main():
    menu_princ()
    menu_pers()
    print("test")
    plateau()
    print("test1")
    tour=0
    
if __name__ == '__main__':
    main()
    