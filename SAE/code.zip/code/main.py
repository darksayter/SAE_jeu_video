from joueur import *
from monstres import *
from objets import *

def main():
    tour=0
    
if __name__ == '__main__':
    main()
    